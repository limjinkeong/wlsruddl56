<form class="search" method="get" action="<?php echo home_url(); ?>">
	<label>
		<input type="search" class="search-field" placeholder="<?php _e('Search …', 'wiloke'); ?>" value="" name="s" title="Search for:">
	</label>
	<input type="submit" class="search-submit" value="">
</form>