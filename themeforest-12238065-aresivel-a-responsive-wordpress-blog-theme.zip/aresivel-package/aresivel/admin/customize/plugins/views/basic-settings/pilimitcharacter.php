<?php
/**
 * Render the content limit
 */
function pi_content_limit($limit=0, $dotted=false)
{
    do_action('pi_before_render_content_limit');

    $limitType  = piBlogCustomize::pi_refresh_in_customize("pi_options[basic_settings][limit_character][display]") ? piBlogCustomize::pi_refresh_in_customize("pi_options[basic_settings][limit_character][display]") : piBlogCustomize::$piOptions['basic_settings']['limit_character']['display'];
    
    if ( $limitType == 'post_content' )
    {
        global $post;

        $link   = "";
        $content = get_the_content( $post->ID );

        $char = piBlogCustomize::pi_refresh_in_customize("pi_options[basic_settings][limit_character][limit]") ? piBlogCustomize::pi_refresh_in_customize("pi_options[basic_settings][limit_character][limit]") : piBlogCustomize::$piOptions['basic_settings']['limit_character']['limit'];
        if ( $limit == 0 )
        {

            if ( !$char ) {
                $max_characters = piBlogCustomize::$piOptions['basic_settings']['limit_character']['limit'];
            }else{
                if ( $char == "empty" )
                {
                    $max_characters = 0;
                }else{
                    $max_characters =   $char;
                }
            }
        }else{
            $max_characters = $limit;
        }

        if ( !empty($max_characters) )
        {
            $content = strip_tags( $content, '<script>,<style>' );

            $content = trim( preg_replace( '#<(s(cript|tyle)).*?</\1>#si', '', $content ) );

            $content = truncate_pharse( $content, $max_characters, $dotted );

            if ( has_filter('pi_the_content_limit') )
            {
                $content = apply_filters('pi_the_content_limit',$content);
            }

            if ( has_filter('pi_more_link') )
            {
                $link = apply_filters('pi_more_link', get_permalink());
            }else{
                $link   = sprintf( '<a href="%1$s" class="%2$s">%3$s</a>', get_permalink(),'pi_more_link', 'Read More' );
            }
        }


        do_action('pi_before_render_excerpt');
        echo '<p>'.wp_unslash($content).'</p>';
        do_action('pi_after_render_excerpt');

        do_action('pi_before_render_readmore');
        echo wp_unslash($link);
        do_action('pi_after_render_readmore');
    }else{
        the_excerpt();
    }

    do_action('pi_after_render_content_limit');
}

function truncate_pharse($text, $max_characters)
{
    $text = trim( $text );
    if(function_exists('mb_strlen'))
    {

        if ( mb_strlen( $text ) > $max_characters ) {
            $text = mb_substr( $text, 0, $max_characters + 1 );
            $text = trim( mb_substr( $text, 0, mb_strrpos( $text, ' ' ) ) );
        }
    }else{
        if ( strlen( $text ) > $max_characters ) {
            $text = substr( $text, 0, $max_characters + 1 );
            $text = trim( substr( $text, 0, strrpos( $text, ' ' ) ) );
        }
    }
    return $text;
}


?>