<?php
/**
 * In the case of page template
 */

function pi_posts_per_page_of_page_template()
{

    if ( piBlogCustomize::pi_refresh_in_customize("pi_options[basic_settings][posts_per_page]") )
    {
        $postPerPages = piBlogCustomize::pi_refresh_in_customize("pi_options[basic_settings][posts_per_page]");

    }else{
        if ( isset(piBlogFramework::$piOptions['basic_settings']['posts_per_page']) )
        {
            $postPerPages = piBlogFramework::$piOptions['basic_settings']['posts_per_page'];
        }else{
            $postPerPages = get_option('posts_per_page');
        }
    }
    return $postPerPages;
}
?>