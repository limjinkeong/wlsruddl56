<?php

/**
 * get custom color
 * @since 1.0
 */
function pi_get_custom_color()
{
    return piBlogCustomize::pi_refresh_in_customize('pi_options[basic_settings][custom_color]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[basic_settings][custom_color]') : piBlogFramework::$piOptions['basic_settings']['custom_color'];
}

?>