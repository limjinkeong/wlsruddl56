<?php
/**
 * Render preloader
 * @since 1.0
 */

function pi_render_preloader()
{
    $status  = piBlogCustomize::pi_refresh_in_customize("pi_options[basic_settings][preloader]")  ? piBlogCustomize::pi_refresh_in_customize("pi_options[basic_settings][preloader]") : piBlogFramework::$piOptions['basic_settings']['preloader'];

    $status  = $status == "disable" || $status == '0' ? 0 : $status;

    if ( !empty($status) ) :
        /*It allows to create other preloader*/
        ?>
        <div class="preloader">
            <span><?php _e('Loading', 'wiloke'); ?></span>
        </div>
<?php
    endif;
}

?>