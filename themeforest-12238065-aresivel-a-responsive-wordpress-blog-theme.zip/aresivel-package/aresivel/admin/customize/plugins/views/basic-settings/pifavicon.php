<?php
/**
 * Render favicon
 */
function pi_render_favicon()
{
    $source  =  piBlogCustomize::pi_refresh_in_customize('pi_options[basic_settings][favicon]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[basic_settings][favicon]') : piBlogFramework::$piOptions['basic_settings']['favicon'];

    if ( !empty($source) )
    {
        echo '<link rel="icon" type="image/x-icon" href="'.esc_url($source).'">';
    }
}
?>