<?php

function pi_render_pagination($query="")
{
    global $post;

    $piPagiStyle  = piBlogCustomize::pi_refresh_in_customize("pi_options[pagination]]") ? piBlogCustomize::pi_refresh_in_customize("pi_options[pagination]") : piBlogFramework::$piOptions['pagination'];

    do_action('pi_before_render_pagination');
    switch (  $piPagiStyle )
    {
        case 'navigation':
            echo '<div class="pi-nav-page"><div class="prev">';
            previous_posts_link( '&laquo; Previous Entries' );
            echo '</div><div class="next">';
            next_posts_link( 'Next Entries &raquo;', '' );
            echo '</div></div>';
            break;

        default:
            if ( empty($query) )
            {
                global $wp_query;
            }else{
                $wp_query = $query;
            }
            $big = 999999999; // need an unlikely integer
            $aConfig = array(
                'prev_text'          => __('« Previous', 'wiloke'),
                'next_text'          => __('Next »', 'wiloke'),
                'before_page_number' => '',
                'after_page_number'  => '',

            );
            if ( has_filter('pi_filter_pagination_style_number') )
            {
                $aConfig = apply_filters("pi_filter_pagination_style_number", $aConfig);
            }
            $aRequires = array(
                'base' 		=> str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                'format' 	=> is_front_page() && 'page' == get_option( 'show_on_front' ) ? '?page=%#%' : '?paged=%#%',
                'current' 	=> max( 1, get_query_var('paged') ),
                'total' 	=> $wp_query->max_num_pages,
                'prev_text' => __('<i class="fa fa-angle-left"></i>'),
                'next_text' => __('<i class="fa fa-angle-right"></i>'),
            );
            $aConfig = array_merge($aConfig, $aRequires);
            echo '<div class="pi-pagination-page">';
            echo paginate_links( $aConfig );
            echo '</div>';


            break;
    }
    do_action('pi_after_render_pagination');
}