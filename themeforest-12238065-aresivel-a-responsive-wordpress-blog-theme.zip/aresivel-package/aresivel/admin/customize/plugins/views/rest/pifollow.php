<?php
/**
 * Render Follow us on social networks
 * @since 1.0
 */

function pi_render_follow($showingTitle = false)
{
    $follow = "";

    foreach ( piConfigs::$aConfigs['configs']['rest']['follow'] as $key => $aInfo )
    {
        $social = piBlogCustomize::pi_refresh_in_customize("pi_options[follow][$key]") ? piBlogCustomize::pi_refresh_in_customize("pi_options[follow][$key]") :
            piBlogFramework::$piOptions['follow'][$key];

        if ( !empty($social) )
        {
            $follow .= '<a href="'.esc_url($social).'" target="_blank"><i class="'.esc_attr($aInfo[0]).'"></i>';
                if ( $showingTitle )
                {
                    $follow .= ' ' . $aInfo[1];
                }
            $follow .= '</a>';
        }
    }

    if ( empty($follow) )
    {
        return;
    }

    do_action('pi_before_render_follow');
        echo '<div class="'.apply_filters('pi_filter_follow_wrapper_class', 'pi-follow').'">';
            if ( has_filter('pi_filter_render_follow') )
            {
                echo apply_filters('pi_filter_render_follow', $follow, array('classes'=>'pi-follow', 'id'=>''));
            }else{
                print $follow;
            }
        echo '</div>';
    do_action('pi_after_render_follow');
}

function pi_render_footer_social()
{
    $follow = "";
    foreach ( piConfigs::$aConfigs['configs']['rest']['follow'] as $key => $aInfo )
    {
        $social = piBlogCustomize::pi_refresh_in_customize("pi_options[follow][$key]") ? piBlogCustomize::pi_refresh_in_customize("pi_options[follow][$key]") :
            piBlogFramework::$piOptions['follow'][$key];

        if ( !empty($social) )
        {
            $follow .= '<a href="'.esc_url($social).'" target="_blank"><i class="'.esc_attr($aInfo[0]).'"></i></a>';
        }
    }

    if ( !empty($follow) )
    {
        $follow = '<div class="footer-social text-center"><div class="pi-social-rotate">'.$follow.'</div></div>';
    }

    print $follow;
}

?>