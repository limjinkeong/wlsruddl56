<?php
/**
 * Return typography
 * @since 1.0
 */
function pi_render_typography()
{
    $css = '';
    $fontfamily = get_option('pi_fontfamily');
    $fontfamily = str_replace('+', ' ', $fontfamily);

    foreach ( piConfigs::$aConfigs['configs']['typography'] as $key )
    {
        $type = piBlogCustomize::pi_refresh_in_customize("pi_options[typography][$key][fonttype]") ? piBlogCustomize::pi_refresh_in_customize("pi_options[typography][$key][fonttype]") : piBlogFramework::$piOptions['typography'][$key]['fonttype'];

        if (  $type != 'default' )
        {
            $css .= $key.'{ font-family: "'.$fontfamily.'";';
            if ( get_option('pi_fontweight')  )
            {
                $fontweight =  piBlogCustomize::pi_refresh_in_customize("pi_options[typography][$key][fontweight]") ? piBlogCustomize::pi_refresh_in_customize("pi_options[typography][$key][fontweight]") : piBlogFramework::$piOptions['typography'][$key]['fontweight'];

                if ( !empty($fontweight) )
                {
                    $fontStyle = preg_replace("/(\d*)/", "", $fontweight);
                    $weight = (int)$fontweight;

                    $css .= 'font-weight: '.$weight.';';

                    if ( !empty($fontStyle) )
                    {
                        $css .= 'font-style: '.wp_unslash($fontStyle) . ';';
                    }
                }
            }
            $css .= "}\n";
        }

    }

    return $css;
}
?>