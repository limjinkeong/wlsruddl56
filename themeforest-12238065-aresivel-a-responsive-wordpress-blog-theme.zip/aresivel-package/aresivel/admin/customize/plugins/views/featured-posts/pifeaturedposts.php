<?php
/**
 * Created by PhpStorm.
 * User: wiloke
 * Date: 7/15/15
 * Time: 12:36 AM
 */

function pi_render_featured_slider()
{
    $toggle = false;

    $toggle = piBlogCustomize::pi_refresh_in_customize('pi_options[featuredposts][toggle]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[featuredposts][toggle]') : piBlogFramework::$piOptions['featuredposts']['toggle'];


    $toggle = $toggle == 'disable' || $toggle == '0' ? false : $toggle;

    if ( $toggle )
    {
        do_action('pi_before_featured_posts');

        $layout         = piBlogCustomize::pi_refresh_in_customize('pi_options[featuredposts][layout]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[featuredposts][layout]') : piBlogFramework::$piOptions['featuredposts']['layout'];
        $type           = piBlogCustomize::pi_refresh_in_customize('pi_options[featuredposts][type]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[featuredposts][type]') : piBlogFramework::$piOptions['featuredposts']['type'];
        $exclude        = piBlogCustomize::pi_refresh_in_customize('pi_options[featuredposts][exclude_featured_posts]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[featuredposts][exclude_featured_posts]') : piBlogFramework::$piOptions['featuredposts']['exclude_featured_posts'];
        $numberOfPosts  = piBlogCustomize::pi_refresh_in_customize('pi_options[featuredposts][number_of_posts]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[featuredposts][number_of_posts]') : piBlogFramework::$piOptions['featuredposts']['number_of_posts'];
        $numberOfPosts  = empty($numberOfPosts) ? 5 : $numberOfPosts;

        $args = array(
            'posts_per_page' => (int)$numberOfPosts,
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'order'          => 'DESC',
            'orderby'        => 'post_date',
            'ignore_sticky_posts' => 1
        );

        if ( $type == 'category' )
        {
            $catID =  piBlogCustomize::pi_refresh_in_customize('pi_options[featuredposts][category]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[featuredposts][category]') : piBlogFramework::$piOptions['featuredposts']['category'];
            $args['cat'] = (int)$catID;
        }elseif($type=='sticky'){
            $args['post__in'] = get_option( 'sticky_posts' );
        }elseif($type=='rand'){
            $args['orderby'] =  'rand';
        }

        $query = new WP_Query($args);
        ?>
        <section class="featured-slider <?php echo esc_attr($layout); ?>">
            <?php
            if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post();
                    piBlogFramework::$piFeaturedPostsId[] = $query->post->ID;
                    $postFormat = get_post_format($query->post->ID);

                    $isGetLink = true;

                    if ( isset($postFormat) && $postFormat == 'link' )
                    {
                        $content = get_the_content($query->post->ID);
                        if ( $content == '' )
                        {
                            $aPostMeta = get_post_meta($query->post->ID, 'pi_post', true);
                            $link      = isset($aPostMeta['link']) ? $aPostMeta['link'] : '';
                            $isGetLink = false;
                            $target    = 'target="_blank"';
                        }
                    }

                    if ( $isGetLink )
                    {
                        $link   = get_permalink($query->post->ID);
                        $target = '';
                    }

                    $postThumbnail = has_post_thumbnail($query->post->ID) ? wp_get_attachment_url( get_post_thumbnail_id( $query->post->ID ), 'pi-featuredslider' ) : 'https://placeholdit.imgix.net/~text?txtsize=33&txt=Feauted%20Image&w=1285&h=485';
                    ?>
                    <div class="item">
                        <div class="background-image" data-background-image="<?php echo esc_url($postThumbnail); ?>"></div>
                        <div class="item-content">
                            <div class="item-cat">
                                <?php echo pi_get_list_of_categories($query->post->ID); ?>
                            </div>
                            <div class="item-title text-uppercase">
                                <h2><a <?php echo esc_attr($target); ?> href="<?php echo esc_url($link); ?>"><?php echo get_the_title($query->post->ID); ?></a></h2>
                            </div>
                            <hr class="pi-divider pi-divider-white">
                            <div class="item-more">
                                <a <?php echo esc_attr($target); ?> href="<?php echo esc_url($link); ?>"><?php _e('Read more', 'wiloke'); ?></a>
                            </div>
                        </div>
                    </div>
                <?php
                endwhile; endif;wp_reset_postdata();

                if ( $exclude != '1' )
                {
                    piBlogFramework::$piFeaturedPostsId = array();
                }
            ?>
        </section>
        <?php
        do_action('pi_after_featured_posts');
    }
}
