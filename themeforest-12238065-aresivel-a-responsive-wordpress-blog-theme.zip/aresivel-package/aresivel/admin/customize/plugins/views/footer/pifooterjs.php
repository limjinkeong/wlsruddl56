<?php
/**
 * Render custom js
 */
function pi_render_footer_custom_js()
{
    $customJs = piBlogCustomize::pi_refresh_in_customize('pi_options[footer][custom_js]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[footer][custom_js]') : piBlogFramework::$piOptions['footer']['custom_js'];
    if ( !empty($customJs) )
    {
        echo '<script type="text/javascript">' . "\n";
        echo  esc_js( str_replace("&#039", '\'', $customJs) );
        echo '</script>' . "\n";
    }
}
?>