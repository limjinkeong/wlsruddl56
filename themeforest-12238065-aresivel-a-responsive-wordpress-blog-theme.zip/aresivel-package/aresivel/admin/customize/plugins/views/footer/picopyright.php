<?php
/**
 * Created by PhpStorm.
 * User: wiloke
 * Date: 7/12/15
 * Time: 4:56 PM
 */

function pi_render_copyright()
{
    $copyright = piBlogCustomize::pi_refresh_in_customize("pi_options[footer][copyright]") ? piBlogCustomize::pi_refresh_in_customize("pi_options[footer][copyright]") : piBlogFramework::$piOptions['footer']['copyright'];

    if ( $copyright )
    {
        do_action('pi_before_copyright');
        if ( has_filter('pi_render_copyright') )
        {
            $copyright = apply_filters('pi_render_copyright', $copyright);
        }else{
            $copyright = '<div class="pi-copyright copyright text-center text-italic"><p>'.esc_html($copyright).'</p></div>';
        }
        echo wp_unslash($copyright);
        do_action('pi_after_copyright');
    }

}