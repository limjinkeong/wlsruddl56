<?php
/**
 * Render Logo
 * @since 1.0
 */
function pi_render_logo()
{
    $logo = piBlogCustomize::pi_refresh_in_customize('pi_options[logoheader][logo]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[logoheader][logo]') : piBlogFramework::$piOptions['logoheader']['logo'];

    if ( !empty($logo) && $logo != 'disable' )
    {
        do_action('pi_before_logo');
        if ( has_filter('pi_render_logo') )
        {
            $logo = apply_filters('pi_render_logo', $logo);
        }else{
            $logo = '<a class="pi-logo logo" href="'.home_url().'"><img src="'.esc_url($logo).'" alt="'.get_option('blogname').'"></a>';
        }
        print $logo;
        do_action('pi_after_logo');
    }
}
?>