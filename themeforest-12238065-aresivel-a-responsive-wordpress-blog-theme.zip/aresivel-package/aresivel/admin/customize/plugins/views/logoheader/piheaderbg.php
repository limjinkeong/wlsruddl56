<?php
/**
 * Created by ninhle - wiloke team
 * @since 1.0
 */
function pi_get_headerbg()
{
    return piBlogCustomize::pi_refresh_in_customize('pi_options[logoheader][headerbg]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[logoheader][headerbg]') : piBlogFramework::$piOptions['logoheader']['headerbg'];
}
?>