<?php
/**
 * Render Header Code
 */
function pi_render_header_custom_code()
{
    $customCode = piBlogCustomize::pi_refresh_in_customize("pi_options[logoheader][header_code]") ? piBlogCustomize::pi_refresh_in_customize("pi_options[logoheader][header_code]") : piBlogFramework::$piOptions['logoheader']['header_code'];
    if ( $customCode !='' )
    {
        $customCode = str_replace("&#039", '\'', $customCode);
        print $customCode."\n";
    }
}
?>