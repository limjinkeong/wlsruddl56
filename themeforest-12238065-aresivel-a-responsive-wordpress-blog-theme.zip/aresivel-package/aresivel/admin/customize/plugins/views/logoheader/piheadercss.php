<?php
/**
 * Render custom css
 */
function pi_render_header_custom_css()
{
    $customCss = piBlogCustomize::pi_refresh_in_customize('pi_options[logoheader][custom_css]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[logoheader][custom_css]') : piBlogFramework::$piOptions['logoheader']['custom_css'];
    if ( !empty($customCss) )
    {
        echo '<style type="text/css">' . "\n";
        echo str_replace("&#039", '\'', $customCss);
        echo '</style>' . "\n";
    }
}
?>