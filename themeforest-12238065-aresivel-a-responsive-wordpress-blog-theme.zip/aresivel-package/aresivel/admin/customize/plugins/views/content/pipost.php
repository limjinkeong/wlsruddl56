<?php
/**
 * Created by PhpStorm.
 * User: wiloke
 * Date: 7/12/15
 * Time: 8:28 PM
 */


/*Related Posts*/
function pi_render_related_posts()
{
    $status  = piBlogCustomize::pi_refresh_in_customize("pi_options[content][related_posts][toggle]")  ? piBlogCustomize::pi_refresh_in_customize("pi_options[related_posts][toggle]") : piBlogFramework::$piOptions['content']['related_posts']['toggle'];

    $status  = $status == "disable" || $status == '0' ? 0 : $status;
    if ( !empty($status) )
    {
        do_action('pi_before_related_posts');

        $by = piBlogCustomize::pi_refresh_in_customize('pi_options[content][related_posts][get_by]') ? piBlogCustomize::pi_refresh_in_customize('pi_options[content][related_posts][get_by]') : piBlogFramework::$piOptions['content']['related_posts']['get_by'];

        global $post;

        if ( $by != 'tag' )
        {
            $getTerms = get_the_category($post->ID);
            $key      = 'category__in';
        }else{
            $getTerms = wp_get_post_tags($post->ID);
            $key      = 'tag__in';
        }

        if ( $getTerms ) :

            foreach ( $getTerms as $term )
            {
                $aBy[] = $term->term_id;
            }

            $args=array(
                'post__not_in'          => array($post->ID),
                'posts_per_page'        => 3,
                'ignore_sticky_posts'   => 1
            );

            $args[$key] = $aBy;

            $query = new WP_Query($args);
            if( $query->have_posts() ) :
                ?>
                <div class="related-post pi-related_posts">
                    <?php  pi_render_related_posts_title(); ?>
                    <div class="pi-row">
                        <?php
                        while ($query->have_posts()) : $query->the_post();
                            ?>
                            <div class="pi-three-column">
                                <div class="related-post-item">
                                    <div class="post-media">
                                        <div class="image-wrap">
                                            <a href="<?php the_permalink(); ?>" rel="bookmark">
                                            <?php
                                            if ( has_post_thumbnail() )
                                            {
                                                the_post_thumbnail( array(245, 165) );
                                            }
                                            ?>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="post-body">
                                        <div class="post-title">
                                            <h2><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
                                        </div>
                                        <span class="post-date"><?php echo pi_get_the_date($post->ID); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php
                        endwhile;
                        ?>
                    </div>
                </div>
            <?php
            endif;wp_reset_postdata();
        endif;
        do_action('pi_after_related_posts');
    }
}
function pi_render_related_posts_title()
{
    $title  = piBlogCustomize::pi_refresh_in_customize("pi_options[content][related_posts][title]")  ? piBlogCustomize::pi_refresh_in_customize("pi_options[content][related_posts][title]") : piBlogFramework::$piOptions['content']['related_posts']['title'];

    if ( !empty($title) )
    {
        do_action('pi_before_related_posts_title');
        if ( has_filter('pi_related_posts_title') )
        {
            $title = apply_filters('pi_related_posts_title', $title);
        }else{
            $title = '<h3 class="related-post-title">'.$title.'</h3>';
        }
        echo wp_unslash($title);
        do_action('pi_after_related_posts_title');
    }

}
/*End / Related Posts*/

/* Sharing Box */
function pi_render_sharing_box_on_post($status=false)
{
    if ( !$status )
    {
        $status  = piBlogCustomize::pi_refresh_in_customize("pi_options[content][sharing_box_on_post][toggle]")  ? piBlogCustomize::pi_refresh_in_customize("pi_options[content][sharing_box_on_post][toggle]") : piBlogFramework::$piOptions['content']['sharing_box_on_post']['toggle'];
    }

    if ( !empty($status) && $status != 'disable' )
    {
        global  $post;
        $sharing_box = "";
        do_action('pi_before_sharing_box');

        $sharing_box .= '<a target="_blank" href="http://www.facebook.com/sharer.php?u='.urlencode(get_permalink($post->ID)).'&amp;t='.urlencode(get_the_title($post->ID)).'"><i class="fa fa-facebook"></i></a>';
        $sharing_box .= '<a target="_blank" href="https://twitter.com/intent/tweet?text='.urlencode(get_the_title($post->ID)) . '-'.urlencode(get_permalink($post->ID)).'&amp;source=webclient"><i class="fa fa-twitter"></i></a>';
        $sharing_box .= '<a target="_blank" href="https://plus.google.com/share?url='.urlencode(get_permalink($post->ID)).'&amp;title='.urlencode(get_the_title($post->ID)).'"><i class="fa fa-google-plus"></i></a>';
        $sharing_box .= '<a target="_blank" href="http://vkontakte.ru/share.php?url='.urlencode(get_permalink($post->ID)).'&amp;title='.urlencode(get_the_title($post->ID)).'"><i class="fa fa-vk"></i></a>';


        if ( has_filter('pi_render_sharing_box') )
        {
            $sharing_box = apply_filters("pi_render_sharing_box", $sharing_box);
        }

        echo apply_filters('pi_filter_before_sharingbox_wrapper', '<div class="pi-sharingbox">');
        echo wp_unslash($sharing_box);
        echo apply_filters('pi_filter_after_sharingbox_wrapper', '</div>');

        do_action('pi_after_sharing_box');
    }
}
/*End / Sharing Box*/

?>