<?php
/**
 * Created by PhpStorm.
 * User: wiloke
 * Date: 7/12/15
 * Time: 9:56 PM
 */

/*Get the status of sharing box on page*/
function pi_is_sharing_box_on_page()
{
    $status  = piBlogCustomize::pi_refresh_in_customize("pi_options[content][sharing_box_on_page][toggle]")  ? piBlogCustomize::pi_refresh_in_customize("pi_options[sharing_box_on_page][toggle]") : piBlogFramework::$piOptions['content']['sharing_box_on_page']['toggle'];

    if ( $status == 'disable' )
    {
        $status = 0;
    }

    return $status;
}

/* Sharing Box */
function pi_render_sharing_box_on_page()
{
    global  $post;

    do_action('pi_before_sharing_box');
    $sharing_box  = "";
    $sharing_box .= '<div class="pi-sharing_box share">';
    $sharing_box .= '<a target="_blank" href="http://www.facebook.com/sharer.php?u='.urlencode(get_permalink($post->ID)).'&amp;t='.urlencode(get_the_title($post->ID)).'"><i class="fa fa-facebook"></i></a>';
    $sharing_box .= '<a target="_blank" href="https://twitter.com/intent/tweet?text='.urlencode(get_the_title($post->ID)) . '-'.urlencode(get_permalink($post->ID)).'&amp;source=webclient"><i class="fa fa-twitter"></i></a>';
    $sharing_box .= '<a target="_blank" href="https://plus.google.com/share?url='.urlencode(get_permalink($post->ID)).'&amp;title='.urlencode(get_the_title($post->ID)).'"><i class="fa fa-google-plus"></i></a>';
    $sharing_box .= '<a target="_blank" href="http://vkontakte.ru/share.php?url='.urlencode(get_permalink($post->ID)).'&amp;title='.urlencode(get_the_title($post->ID)).'"><i class="fa fa-vk"></i></a>';
    
    if ( has_post_thumbnail($post->ID) )
    {
        $media = '&amp;media='.urlencode(wp_get_attachment_url( get_post_thumbnail_id($post->ID) ));
    }
    $sharing_box .= '<a data-pin-do target="_blank" href="https://pinterest.com/pin/create/button/?url='.urlencode(get_permalink($post->ID)).$media.'&amp;description='.urlencode(get_the_title($post->ID)).'"><i class="fa fa-pinterest"></i></a>';
    $sharing_box .= '</div>';

    if ( has_filter('pi_render_sharing_box') )
    {
        $sharing_box = apply_filters("pi_render_sharing_box", $sharing_box);
    }

    echo apply_filters('pi_filter_before_sharingbox_wrapper', '<div class="pi-sharingbox">');
    echo wp_unslash($sharing_box);
    echo apply_filters('pi_filter_after_sharingbox_wrapper', '</div>');

    do_action('pi_after_sharing_box');

}
/*End / Sharing Box*/

/* Page Sidebar */
function pi_get_sidebar_on_page()
{
    $sidebar = piBlogCustomize::pi_refresh_in_customize("pi_options[content][sidebar_on_page]")  ? piBlogCustomize::pi_refresh_in_customize("pi_options[sidebar_on_page]") : piBlogFramework::$piOptions['content']['sidebar_on_page'];
    if ( $sidebar == 'default' )
    {
        $sidebar = pi_get_sidebar_layout();
    }
    return $sidebar;
}
/* End / Page Sidebar */