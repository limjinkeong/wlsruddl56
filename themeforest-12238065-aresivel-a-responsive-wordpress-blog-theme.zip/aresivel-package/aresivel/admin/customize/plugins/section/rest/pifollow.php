<?php
/**
 * Follow us
 * It allows filter panel
 * @since 1.0
 */

$wp_customize->add_section(
    'pi_follow',
    array(
        'title'     => __('Follow', 'wiloke'),
        'panel'     => apply_filters('pi_filter_panel_of_follow', 'pi_footer_panel'),
        'priority'  => $this->piPanelPriority++,
        'description'=>__('This setting will be displayed at the topbar menu and footer', 'wiloke')
    )
);

/**
 * @param $aInfo: $aInfo[0] the fontawesome code. $aInfo[1] the name of this social
 */
foreach ( piConfigs::$aConfigs['configs']['rest']['follow'] as $name => $aInfo )
{
    $wp_customize->add_setting(
        "pi_options[follow][$name]",
        array(
            'type'              => 'option',
            'capability'        => 'edit_theme_options',
            'default'           => esc_url(parent::$piOptions['follow'][$name]),
            'sanitize_callback' => array($this, 'pi_sanitize_data')
        )
    );

    $wp_customize->add_control(
        "pi_options[follow][$name]",
        array(
            'type'      => 'url',
            'priority'  => $this->piControlPriority++,
            'label'     => $aInfo[1],
            'section'   => 'pi_follow',
            'settings'  => "pi_options[follow][$name]"
        )
    );
}

?>