<?php
/**
 * Created by PhpStorm.
 * User: wiloke
 * Date: 7/15/15
 * Time: 12:33 AM
 */

$wp_customize->add_section('pi_featured_posts', array(
    'title'     => __('Settings', 'wiloke'),
    'panel'     => 'pi_featured_posts_panel',
    'priority'  => $this->piSectionPriority++
));


/*Toggle*/
$wp_customize->add_setting(
    "pi_options[featuredposts][toggle]",
    array(
        'default'       =>  self::$piOptions['featuredposts']['toggle'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[featuredposts][toggle]',
    array(
        'label' 	=> __('Enable/Disable', 'wiloke'),
        'section' 	=> 'pi_featured_posts',
        'settings' 	=> 'pi_options[featuredposts][toggle]',
        'priority'  => $this->piControlPriority++,
        'type' 		=> 'select',
        'choices' 	=> array(
                        1 => 'Enable',
                        0 => 'Disable'
                    )
    )
);

/*Layout*/
$wp_customize->add_setting(
    "pi_options[featuredposts][layout]",
    array(
        'default'           =>  parent::$piOptions['featuredposts']['layout'],
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control("pi_options[featuredposts][layout]",
    array(
        'label'     => __('Layout', 'wiloke'),
        'section'   => 'pi_featured_posts',
        'settings'  => 'pi_options[featuredposts][layout]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'select',
        'choices'   => array(
            'pi-fullwidth'     => __('Fullwidth', 'wiloke'),
            'pi-container'     => __('Boxed', 'wiloke')
        ),
    )
);

/*Type*/
$wp_customize->add_setting(
    "pi_options[featuredposts][type]",
    array(
        'default'           =>  parent::$piOptions['featuredposts']['type'],
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control("pi_options[featuredposts][type]",
    array(
        'label'     => __('Get By', 'wiloke'),
        'section'   => 'pi_featured_posts',
        'settings'  => 'pi_options[featuredposts][type]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'select',
        'choices'   => array(
            'latest'     => __('Latest Posts', 'wiloke'),
            'sticky'     => __('Sticky Posts', 'wiloke'),
            'category'   => __('Category', 'wiloke'),
            'rand'       => __('Random', 'wiloke')
        ),
    )
);

/*category listing*/
$wp_customize->add_setting(
    "pi_options[featuredposts][category]",
    array(
        'default'           => -1,
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[featuredposts][category]',
    array(
        'label'    => __('Choose Category', 'wiloke'),
        'section'  => 'pi_featured_posts',
        'settings' => 'pi_options[featuredposts][category]',
        'priority' => $this->piControlPriority++,
        'type'     => 'select',
        'choices'  => parent::pi_get_categories()
    )
);

/*Number of posts*/
$wp_customize->add_setting(
    "pi_options[featuredposts][number_of_posts]",
    array(
        'default'       => parent::$piOptions['featuredposts']['number_of_posts'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[featuredposts][number_of_posts]',
    array(
        'label'    => __('Number Of Posts', 'wiloke'),
        'section'  => 'pi_featured_posts',
        'settings' => 'pi_options[featuredposts][number_of_posts]',
        'priority' => $this->piControlPriority++,
        'type'     => 'text',
    )
);


/*Exclude featured slider*/
$wp_customize->add_setting(
    "pi_options[featuredposts][exclude_featured_posts]",
    array(
        'default'       => parent::$piOptions['featuredposts']['exclude_featured_posts'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);
$wp_customize->add_control('pi_options[featuredposts][exclude_featured_posts]',
    array(
        'label'     => __('Exclude Featured Posts', 'wiloke'),
        'section'   => 'pi_featured_posts',
        'settings'  => 'pi_options[featuredposts][exclude_featured_posts]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'select',
        'choices'   => array(
                        0 => 'Disable',
                        1 => 'Enable'
                    )
    )
);

/*Description for featured slider*/
$wp_customize->add_setting(
    "pi_options[featuredposts][des_exclude_posts]",
    array(
        'default'       =>  '',
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control( new piDescription(
        $wp_customize,
        "pi_options[featuredposts][des_exclude_posts]",
        array(
            "priority"  => $this->piControlPriority++,
            "type"       => "description",
            "label"      => __( apply_filters('pi_filter_des_exclude_featured_posts', 'Don\'t show the featured posts on the content area'), 'wiloke' ),
            "section"    => "pi_featured_posts",
            "settings"   => "pi_options[featuredposts][des_exclude_posts]"
        )
    )
);