<?php
/**
 * Created by wiloke.
 * User: wiloke
 * Date: 7/12/15
 * Time: 8:28 PM
 */

$wp_customize->add_section('pi_post', array(
    'title'     => __('Post', 'wiloke'),
    'panel'     => 'pi_content_panel',
    'priority'  => $this->piSectionPriority++
));


/*Related Posts*/

/*Relate post title*/
$wp_customize->add_setting(
    'pi_options_relate_posts_title',
    array(
        'type'              =>'',
        'default'           =>'',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control(
    new piTitle(
        $wp_customize,
        'pi_options_relate_posts_title',
        array(
            'label'     => __('Related Posts', 'wiloke'),
            'type'      => 'title',
            'priority'  => $this->piControlPriority++,
            'settings'  => 'pi_options_relate_posts_title',
            'section'   => 'pi_post'
        )
    )
);


/*Toggle*/
$wp_customize->add_setting(
    "pi_options[content][related_posts][toggle]",
    array(
        'default'       =>  parent::$piOptions['content']['related_posts']['toggle'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][related_posts][toggle]',
    array(
        'label' => __('Enable/Disable', 'wiloke'),
        'section' => 'pi_post',
        'settings' => 'pi_options[content][related_posts][toggle]',
        'priority'      => $this->piControlPriority++,
        'type' => 'select',
        'choices' => array(
            1 => 'Enable',
            0 => 'Disable'
        ),
    )
);

/*Title*/
$wp_customize->add_setting(
    "pi_options[content][related_posts][title]",
    array(
        'default'       =>  parent::$piOptions['content']['related_posts']['title'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][related_posts][title]',
    array(
        'label'    => __('Title', 'wiloke'),
        'section'  => 'pi_post',
        'settings' => 'pi_options[content][related_posts][title]',
        'priority' => $this->piControlPriority++,
        'type'     => 'text',
    )
);

/*Get By*/
$wp_customize->add_setting(
    "pi_options[content][related_posts][get_by]",
    array(
        'default'       =>  parent::$piOptions['content']['related_posts']['get_by'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][related_posts][get_by]',
    array(
        'label' => __('Get by', 'wiloke'),
        'section' => 'pi_post',
        'settings' => 'pi_options[content][related_posts][get_by]',
        'priority'      => $this->piControlPriority++,
        'type' => 'select',
        'choices' => array(
            'category' => 'Category',
            'tags' => 'Tags'
        ),
    )
);

/*Number Of Posts*/
$wp_customize->add_setting(
    "pi_options[content][related_posts][number_of_posts]",
    array(
        'default'       =>  parent::$piOptions['content']['related_posts']['number_of_posts'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][related_posts][number_of_posts]',
    array(
        'label'    => __('Number Of Posts', 'wiloke'),
        'section'  => 'pi_post',
        'settings' => 'pi_options[content][related_posts][number_of_posts]',
        'priority' => $this->piControlPriority++,
        'type'     => 'text',
    )
);


/*End / Related Posts*/

/* Sharing box */

/*Sharing box title*/
//$wp_customize->add_setting(
//    'pi_options_sharing_box_title',
//    array(
//        'type'              =>'',
//        'default'           =>'',
//        'capability'        => 'edit_theme_options',
//        'sanitize_callback' => array($this, 'pi_sanitize_data')
//    )
//);
//
//$wp_customize->add_control(
//    new piTitle(
//        $wp_customize,
//        'pi_options_sharing_box_title',
//        array(
//            'label'     => __('Sharing box', 'wiloke'),
//            'type'      => 'title',
//            'priority'  => $this->piControlPriority++,
//            'settings'  => 'pi_options_sharing_box_title',
//            'section'   => 'pi_post'
//        )
//    )
//);

/*Toggle*/
//$wp_customize->add_setting(
//    "pi_options[content][sharing_box_on_post][toggle]",
//    array(
//        'default'           =>  parent::$piOptions['content']['sharing_box_on_post']['toggle'],
//        'type'              => 'option',
//        'capability'        => 'edit_theme_options',
//        'sanitize_callback' => array($this, 'pi_sanitize_data')
//    )
//);
//
//$wp_customize->add_control('pi_options[content][sharing_box_on_post][toggle]',
//    array(
//        'label'     => __('Enable/Disable', 'wiloke'),
//        'section'   => 'pi_post',
//        'settings'  => 'pi_options[content][sharing_box_on_post][toggle]',
//        'priority'  => $this->piControlPriority++,
//        'type'      => 'select',
//        'choices'   => array(
//                        1 => 'Enable',
//                        0 => 'Disable'
//                    )
//    )
//);
/* End / Sharing Box */


?>