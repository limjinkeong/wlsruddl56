<?php
/**
 * Created by PhpStorm.
 * User: wiloke
 * Date: 7/15/15
 * Time: 8:33 PM
 */

$wp_customize->add_section(
    'pi_archive_layout',
    array(
        'title'     => __('Archive Layout', 'wiloke'),
        'panel'     => 'pi_content_panel',
        'priority'  => $this->piSectionPriority++
    )
);

$wp_customize->add_setting(
    "pi_options[content][archive_layout]",
    array(
        'default'       =>  parent::$piOptions['content']['archive_layout'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][archive_layout]',
    array(
        'label'     => '',
        'section'   => 'pi_archive_layout',
        'settings'  => 'pi_options[content][archive_layout]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'select',
        'choices'   => array(
            'standard'              => __('Standard', 'wiloke'),
            'grid' 	                => __('Grid', 'wiloke'),
            'grid_first-large' 	    => __('Grid - 1st large', 'wiloke'),
            'list'                  => __('List', 'wiloke'),
            'list_first-large'      => __('List - 1st large', 'wiloke')
        )
    )
);