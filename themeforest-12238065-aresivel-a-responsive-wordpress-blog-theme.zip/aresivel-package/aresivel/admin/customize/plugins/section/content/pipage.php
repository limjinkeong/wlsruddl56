<?php
/**
 * Created by PhpStorm.
 * User: wiloke
 * Date: 7/12/15
 * Time: 9:56 PM
 */

$wp_customize->add_section(
    'pi_page',
    array(
        'title'         => __('Page', 'wiloke'),
        'capability'    => 'edit_theme_options',
        'panel'         => 'pi_content_panel',
        'priority'      => $this->piSectionPriority++,
        'description'   => __('The sidebar setting  will change the default sidebar position', 'wiloke')
    )
);

/*Sharing Box*/
$wp_customize->add_setting(
    "pi_options[content][sharing_box_on_page][toggle]",
    array(
        'default'           =>  parent::$piOptions['content']['sharing_box_on_page']['toggle'],
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][sharing_box_on_page][toggle]',
    array(
        'label'     => __('Enable/Disable Sharing Box', 'wiloke'),
        'section'   => 'pi_page',
        'settings'  => 'pi_options[content][sharing_box_on_page][toggle]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'select',
        'choices'   => array(
            1 => 'Enable',
            0 => 'Disable'
        )
    )
);
/* End / Sharing Box */

/*Sidebar*/
$wp_customize->add_setting(
    "pi_options[content][sidebar_on_page]",
    array(
        'default'           =>  parent::$piOptions['content']['sidebar_on_page'],
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control('pi_options[content][sidebar_on_page]',
    array(
        'label'     => __('Sidebar', 'wiloke'),
        'section'   => 'pi_page',
        'settings'  => 'pi_options[content][sidebar_on_page]',
        'priority'  => $this->piControlPriority++,
        'type'      => 'select',
        'choices'   => array(
            'default'     => __('Default', 'wiloke'),
            'no-sidebar'  => __('Turn Off', 'wiloke'),
        )
    )
);
/* End / Sharing Box */