<?php
/**
 * Created by ninhle - wiloke team.
 * Date: 7/19/15
 * Time: 10:35 AM
 */

$wp_customize->add_section(
    'pi_headerbg',
    array(
        'title'     => __('Header Background', 'wiloke'),
        'panel'     => 'pi_logoheader_panel',
        'priority'  => $this->piSectionPriority++
    )
);

$wp_customize->add_setting(
    'pi_options[logoheader][headerbg]',
    array(
        'default'       =>  esc_url(parent::$piOptions['logoheader']['headerbg']),
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control(
    new WP_Customize_Image_Control(
        $wp_customize,
        'pi_options[logoheader][headerbg]',
        array(
            'label'      => __( 'Upload', 'wiloke' ),
            'section'    => 'pi_headerbg',
            'settings'   => 'pi_options[logoheader][headerbg]',
        )
    )
);