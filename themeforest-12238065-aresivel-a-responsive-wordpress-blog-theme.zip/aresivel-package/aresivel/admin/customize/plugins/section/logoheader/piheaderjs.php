<?php
/**
 * Custom Js
 * @since 1.0
 */
$wp_customize->add_section('pi_header_custom_js', array(
    'title'     => __('Custom js', 'wiloke'),
    'panel'     => 'pi_logoheader_panel',
    'priority'  => $this->piSectionPriority++,
    'description'=>'Using double quote (\') instead of single quote (")'
));

$wp_customize->add_setting(
    "pi_options[logoheader][custom_js]",
    array(
        'default'       =>  esc_textarea(parent::$piOptions['logoheader']['custom_js']),
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control( new piTextarea(
    $wp_customize,
    'pi_options[logoheader][custom_js]',
    array(
        'label'      => __( 'Custom js', 'wiloke' ),
        'priority'   => $this->piControlPriority++,
        'section'    => 'pi_header_custom_js',
        'settings'   => 'pi_options[logoheader][custom_js]'
    )
));


?>