<?php
/**
 * Custom Css
 * @since 1.0
 */
$wp_customize->add_section('pi_header_custom_css', array(
    'title'     => __('Custom Css', 'wiloke'),
    'panel'     => 'pi_logoheader_panel',
    'priority'  => $this->piSectionPriority++
));

$wp_customize->add_setting(
    "pi_options[logoheader][custom_css]",
    array(
        'default'           =>  esc_textarea(parent::$piOptions['logoheader']['custom_css']),
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control( new piTextarea(
    $wp_customize,
    'pi_options[logoheader][custom_css]',
    array(
        'label'      => __( 'Custom Css', 'wiloke' ),
        'priority'   => $this->piControlPriority++,
        'section'    => 'pi_header_custom_css',
        'settings'   => 'pi_options[logoheader][custom_css]'
    )
));
?>