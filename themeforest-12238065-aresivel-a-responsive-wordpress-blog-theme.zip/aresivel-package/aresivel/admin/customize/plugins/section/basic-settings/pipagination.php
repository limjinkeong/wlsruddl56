<?php
/**
 * Set the type of pagination
 * @since 1.0
 */
//$wp_customize->add_section('pi_pagination', array(
//    'title'     => __('Pagination', 'wiloke'),
//    'panel'     => 'pi_basic_settings_panel',
//    'priority'  => $this->piSectionPriority++
//));
//
//$wp_customize->add_setting(
//    'pi_options[basic_settings][pagination]',
//    array(
//        'default'           =>  parent::$piOptions['basic_settings']['pagination'],
//        'type'              =>  'option',
//        'capability'        =>  'edit_theme_options',
//        'sanitize_callback' =>  array($this, 'pi_sanitize_data')
//    )
//);
//$wp_customize->add_control(
//    'pi_options[basic_settings][pagination]',
//    array(
//        'label'         => __('Style', 'wiloke'),
//        'section'       => 'pi_pagination',
//        'settings'      => 'pi_options[basic_settings][pagination]',
//        'priority'      => $this->piControlPriority++,
//        'type'          => 'select',
//        'choices'       => array(
//                            'navigation' => 'Next &amp; Prev',
//                            'number'     => 'Number'
//                        )
//    )
//);
?>