<?php
/**
 * Enable/Disable Preloader
 * @since 1.0
 */

$wp_customize->add_section(
    'pi_preloader',
    array(
        'title'     => __('Preloader', 'wiloke'),
        'priority'  => $this->piSectionPriority++,
        'panel'     => 'pi_basic_settings_panel'
    )
);

$wp_customize->add_setting(
    'pi_options[basic_settings][preloader]',
    array(
        'default'           => parent::$piOptions['basic_settings']['preloader'],
        'type'              => 'option',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control(
    'pi_options[basic_settings][preloader]',
    array(
        'label'     => __('Enable/Disable', 'wiloke'),
        'type'      => 'select',
        'settings'  => 'pi_options[basic_settings][preloader]',
        'section'   => 'pi_preloader',
        'priority'  => $this->piControlPriority++,
        'choices'   => array(
                        'enable'  => 'Enable',
                        'disable' => 'Disable'
                    )
    )
);

?>