<?php
/**
 * Set limit character
 */
$wp_customize->add_section('pi_limit_charater', array(
   'title'     => __('Limit Character', 'wiloke'),
   'panel'     => 'pi_basic_settings_panel',
   'priority'  => $this->piSectionPriority++
));

/**
 * There are 2 cases: Displaying post excerpt or displaying post content.
 * If it's post excerpt, we will use the_excerpt function else go to handle.
 * @since 1.0
 */
$wp_customize->add_setting(
   'pi_options[basic_settings][limit_character][display]',
   array(
       'default'           =>  parent::$piOptions['basic_settings']['limit_character']['display'],
       'type'              =>  'option',
       'capability'        =>  'edit_theme_options',
       'sanitize_callback' =>  array($this, 'pi_sanitize_data')
   )
);
$wp_customize->add_control(
   'pi_options[basic_settings][limit_character][display]',
   array(
       'label'         => __('Display', 'wiloke'),
       'section'       => 'pi_limit_charater',
       'settings'      => 'pi_options[basic_settings][limit_character][display]',
       'priority'      => $this->piControlPriority++,
       'type'          => 'select',
       'choices'       => array(
                           'post_content' => __('Post Content', 'wiloke'),
                           'post_excerpt' => __('Post Excerpt', 'wiloke')
                       )
   )
);

/**
 * If You have choosen the post content above, we will set limit character
 * @since 1.0
 */
$wp_customize->add_setting(
   'pi_options[basic_settings][limit_character][limit]',
   array(
       'default'           =>  parent::$piOptions['basic_settings']['limit_character']['limit'],
       'type'              =>  'option',
       'capability'        =>  'edit_theme_options',
       'sanitize_callback' =>  array($this, 'pi_sanitize_data')
   )
);
$wp_customize->add_control(
   'pi_options[basic_settings][limit_character][limit]',
   array(
       'label'         => __('Display', 'wiloke'),
       'section'       => 'pi_limit_charater',
       'settings'      => 'pi_options[basic_settings][limit_character][limit]',
       'priority'      => $this->piControlPriority++,
       'type'          => 'text'
   )
);

$wp_customize->add_setting(
   'pi_description_limit_character',
   array(
       'default'           =>  '',
       'type'              =>  'option',
       'capability'        =>  'edit_theme_options',
       'sanitize_callback' =>  array($this, 'pi_sanitize_data')
   )
);
$wp_customize->add_control( new piDescription(
       $wp_customize,
       'pi_description_limit_character',
       array(
           'priority'   => $this->piControlPriority++,
           'type'       => 'description',
           'label'      => __('Set 0 to no limited content', 'wiloke'),
           'section'    => 'pi_limit_charater',
           'settings'   => 'pi_description_limit_character'
       )
   )
);

?>