<?php
/**
 * Footer code
 * @since 1.0
 */
$wp_customize->add_section('pi_footer_custom_code', array(
    'title'     => __('Custom Code', 'wiloke'),
    'panel'     => 'pi_footer_panel',
    'priority'  => $this->piSectionPriority++
));

$wp_customize->add_setting(
    'pi_options[footer][footer_code]',
    array(
        'default'       =>  esc_textarea(parent::$piOptions['footer']['footer_code']),
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control( new piTextarea(
    $wp_customize,
    'pi_options[footer][footer_code]',
    array(
        'label'      => __( '', 'wiloke' ),
        'section'    => 'pi_footer_custom_code',
        'priority'   => $this->piControlPriority++,
        'settings'   => 'pi_options[footer][footer_code]'
    )
));

?>