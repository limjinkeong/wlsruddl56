<?php
/**
 * Created by wiloke.
 * User: wiloke
 * Date: 7/12/15
 * Time: 4:54 PM
 */

$wp_customize->add_section(
    'pi_copyright',
    array(
        'title'=>__('Copyright', 'wiloke'),
        'panel'     => 'pi_footer_panel',
        'priority'  => $this->piSectionPriority++
    )
);
$wp_customize->add_setting(
    "pi_options[footer][copyright]",
    array(
        'default'       =>  parent::$piOptions['footer']['copyright'],
        'type'          => 'option',
        'capability'    => 'edit_theme_options',
        'sanitize_callback' => array($this, 'pi_sanitize_data')
    )
);

$wp_customize->add_control( new piTextarea(
        $wp_customize,
        'pi_options[footer][copyright]',
        array(
            'priority'  => $this->piControlPriority++,
            'label'     => __( 'Copyright', 'wiloke' ),
            'section'	=> 'pi_copyright',
            'settings'	=> 'pi_options[footer][copyright]'
        )
    )
);
